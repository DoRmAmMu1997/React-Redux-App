import React from 'react';
import {Drawer, Input, Form, Button} from 'antd';
import PropTypes from 'prop-types';
const layout = {labelCol: {span: 8}, wrapperCol: {span: 16}};

const AddDrawer = ({show, handleOnClose, OnFinish, OnFinishFailed, initialVals, mode, OnEditFinish}) => {
    const [form] = Form.useForm();
    return (
    <Drawer title={(mode === 'edit' ? 'Edit Contact' : 'Add Contact')} visible={show} onClose={handleOnClose} maskClosable={false} width={400}>
        <Form {...layout} form={form} initialValues={initialVals} name="basic" onFinish={mode === 'edit' ? OnEditFinish : OnFinish} onFinishFailed={OnFinishFailed} autoComplete='false'>
            <Form.Item name='name' label='Enter Name' autoComplete='false' rules={[{ required: true, message: 'Please input name!' },]} style={{width:300, margin:20}}>
            <Input style={{width:200}} placeholder='Name' autocomplete='off'></Input></Form.Item>
            <Form.Item name='job' label='Enter Job' autoComplete='false' rules={[{ required: true, message: 'Please input job!' },]} style={{width:300, margin:20}}>
            <Input style={{width:200}} placeholder='Job' autocomplete='off'></Input></Form.Item>
            <Form.Item name='salary' label='Enter Salary' autoComplete='false' rules={[{ required: true, message: 'Please input salary!' },]} style={{width:300, margin:20}}>
            <Input type='number' style={{width:200}} placeholder='Salary' autocomplete='off'></Input></Form.Item>
            <Form.Item style={{alignContent:"center"}}>
                <Button type='primary' htmlType='submit' padding={20} style={{margin:20}}>{(mode === 'edit' ? 'Modify' : 'Add')}</Button>
                <Button htmlType='button' onClick={() => form.resetFields()} padding={20} style={{margin:5}}>Reset</Button>
            </Form.Item>
        </Form>
    </Drawer>
    );
}

AddDrawer.propTypes = {
    show : PropTypes.bool.isRequired,
    handleOnClose : PropTypes.func.isRequired,
    OnFinish: PropTypes.func.isRequired,
    OnFinishFailed : PropTypes.func.isRequired,
    initialVals : PropTypes.object.isRequired,
    mode : PropTypes.oneOf(['add', 'edit']),
    OnEditFinish : PropTypes.func.isRequired
}

export default AddDrawer;