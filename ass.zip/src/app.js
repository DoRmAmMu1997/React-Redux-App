import React from 'react';
import './index.css';
import {Typography, Button, Layout, Table, Avatar} from 'antd';
import 'antd/dist/antd.css';
import AddDrawer from './addDrawer';
import {PlusCircleFilled, DeleteOutlined, EditFilled} from '@ant-design/icons'
import {connect} from 'react-redux';
import {addContact, deleteContact, editContact} from './redux/contacts/actions'
const{Header, Sider, Content, Footer} = Layout;
const{Text, Title} = Typography;

const MyApp = ({contacts, addContact, deleteContact, editContact}) => {
  const [showDrawer, setShowDrawer] = React.useState(false);
  const [contact, setContact] = React.useState({name: null, job: null, salary:null});
  const [errorInfo, setErrorInfo] = React.useState('');
  const [mode, setMode] = React.useState();
  const [key, setKey] = React.useState();
  const handleFinish = (data) => {
    addContact({
        key: contacts.length - 1, ...data
    })
    setShowDrawer(false);
    window.location.reload(false);
  };
  const handleEditFinish = (data) => {
    editContact({key, ...data});
    setShowDrawer(false);
  };
  const handleFinishFailed = errorInfo => {
    setErrorInfo(errorInfo);
  };
  const handleClose = () => {
    setContact({name: null, job: null, salary:null});
    setMode("add");
    setKey(null);
    setShowDrawer(false);
  }
  const openEditDrawer = (contact, key) => {
    setContact(contact);
    setKey(key);
    setShowDrawer(true);
    setMode("edit");
  };
  console.log(errorInfo);
  const cols = [
    {title:'Name', dataIndex:'name', key:'name'},
    {title:'Job', dataIndex:'job', key:'job'},
    {title:'Salary in $ per year', dataIndex:'salary', key:'salary'},
    {title:'Action', key:'action', render: (text, record) => (
        <span>
            <Button icon={<DeleteOutlined />} onClick={() => deleteContact(record.key)}>Delete</Button>
            <Button style={{marginLeft:5}} icon={<EditFilled />} onClick={() => openEditDrawer(record)}>Modify</Button>
        </span>
      )}
  ];
  return (
    <div>
      <Layout>
        <Header style={{textAlign:"center", padding:20, height:100}}>
          <Avatar style={{float:"right"}} size={60} src='./mypic.jpg'></Avatar>
          <Title style={{color:"white"}}>My Application</Title>
        </Header>
        <Layout>
          <Sider width={200} style={{background:"green", padding:20}}>
            <div> 
            </div>
          </Sider>
          <Layout>
            <Content style={{height:600, padding:20}} align='center'>
              <Button type='primary' icon={<PlusCircleFilled />} onClick={() => setShowDrawer(true)} style={{marginBottom:20, marginLeft:20, marginRight:20}}>ADD</Button><br />
              <Table dataSource={contacts} columns={cols} pagination={{pageSize:5}}></Table>
            </Content>
            <Footer style={{textAlign:"center", padding:20}}><Text>Hope you enjoyed</Text></Footer>
          </Layout>
        </Layout>
      </Layout>
      <AddDrawer show={showDrawer} handleOnClose={handleClose} OnFinish={handleFinish} OnFinishFailed={handleFinishFailed} initialVals={contact} mode={mode} OnEditFinish={handleEditFinish}></AddDrawer>
    </div>
  )
}

const mapStateToProps = (state) => {
    return{
        contacts: state.contacts && state.contacts.allContacts,
    }
}
const mapDispatchToProps = (dispatch) => {
    return{
        addContact: (contact) => {
            dispatch(addContact(contact));
        },
        deleteContact: (key) => {
            dispatch(deleteContact(key));
        },
        editContact: (contact) => {
            dispatch(editContact(contact));
        }
    };
};

export default connect(mapStateToProps, mapDispatchToProps)(MyApp);